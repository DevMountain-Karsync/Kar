var secret = {


 host     : 'ec2-52-32-196-63.us-west-2.compute.amazonaws.com',
 user     : 'root',
 password : 'M@k3GreatApps12',
 database : "KarSyncDev",


}



module.exports = secret;
