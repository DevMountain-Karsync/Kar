angular.module('karSync')
.controller('scheduleCtrl', function($scope){
});
