angular.module('karSync')
.controller('currentCtrl', function($scope){

});
