angular.module('karSync')
.controller('addCtrl', function($scope){

});
