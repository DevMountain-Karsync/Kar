angular.module('karSync')
.controller('loginCtrl', function($scope){

});
